'''
Filters the blast results to select those fulfilling user-specified conditions
(see 'config.yaml')
then calls msa on them.
A. Vargas Richards, 09.08.2024
'''





