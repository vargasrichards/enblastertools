# ORF Predictor relying on NCBI ORF finder
# https://ftp.ncbi.nlm.nih.gov/genomes/TOOLS/ORFfinder/linux-i64/

import subprocess